<?php $__env->startSection('content'); ?>

<!-- ============================================================== -->
<!-- Page Content -->
<!-- ============================================================== -->
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row bg-title">
            <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                <h4 class="page-title">product</h4>
            </div>
            <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                <button class="right-side-toggle waves-effect waves-light btn-info btn-circle pull-right m-l-20"><i class="ti-settings text-white"></i></button>
                <a href="javascript: void(0);" target="_blank" class="btn btn-danger pull-right m-l-20 hidden-xs hidden-sm waves-effect waves-light">Admin Panel</a>
                <ol class="breadcrumb">
                    <li><a href="#">Dashboard</a></li>
                    <li class="active">
                        <?php if(isset($data)): ?>
                        Edit product
                        <?php else: ?>
                        Create new product
                        <?php endif; ?>
                    </li>
                </ol>
            </div>
        </div>
        <!-- .row -->
        <div class="row">
            <div class="col-md-8 col-md-offset-2 col-xs-12">
                <div class="white-box">
                    <ul class="nav nav-tabs tabs customtab">
                        <li class="tab">
                            <a href="#settings" data-toggle="tab" aria-expanded="false"> <span class="visible-xs"><i class="fa fa-cog"></i></span> <span class="hidden-xs">insert your product title</span> </a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <form class="form-horizontal" method="POST" <?php if(isset($data)): ?> action="<?php echo e(url('product/'.$data->id)); ?>" <?php else: ?> action="<?php echo e(url('product')); ?>" <?php endif; ?>>
                            <?php echo e(csrf_field()); ?>

                            <?php if(isset($data)): ?>
                            <?php echo method_field('PATCH'); ?>
                            <?php endif; ?>
                            <input type="hidden" name="workplace_id" value="<?php echo e($workplace->id); ?>" />
                            <div class="row">
                                <div class="col-md-12">
                                    <div>
                                        <label class="control-label">product Title</label>
                                        <input required type="text" class="form-control" value="<?php if(isset($data)): ?> <?php echo e($data->title); ?> <?php endif; ?>" name="title" />
                                    </div>

                                </div>
                            </div>
                            <div class="row">
                                <div class="form-actions m-t-40">
                                    <button type="submit" class="btn btn-danger"> <i class="fa fa-check"></i>
                                        Save</button>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.row -->
    </div>
    <!-- /#page-wrapper -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/malexs5/public_html/closor/resources/views/products/add.blade.php ENDPATH**/ ?>