<?php $__env->startSection('content'); ?>

<!-- ============================================================== -->
<!-- Page Content -->
<!-- ============================================================== -->
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row bg-title">
            <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                <h4 class="page-title">Workplace</h4>
            </div>
            <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                <ol class="breadcrumb">
                    <li><a href="#">Dashboard</a></li>
                    <li class="active">Workplaces</li>
                </ol>
            </div>
        </div>
        <!-- .row -->
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-info">
                    <div class="panel-wrapper collapse in" aria-expanded="true">
                        <div class="panel-body">
                            <div class="alert alert-info" role="alert">
                                <h3 style="color: #31708f;"><strong><i class="mdi mdi-alert-circle-outline fa-fw"></i>
                                        Welcome Onboard!</strong></h3>

                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatum, doloremque.
                                </p>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatum, doloremque.</p>
                            </div>

                                <form class="form-horizontal" method="POST"
                                    action="<?php echo e(url('invite_member_workplace')); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" name="workplace_id" value="<?php echo e(session('workplace')->id); ?>" />
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div>
                                                <label for="email" class="m-t-20">Email</label>
                                                <input required id="email" type="email" class="form-control m-b-10" value=""
                                                    name="email" required placeholder="Email .. ex@example.com" />
                                            </div>
                                        </div>
                                        <div class="col-xs-8 ">
                                            <label for="products" class="m-t-20">Assign Products</label>
                                            <select id="products" name="products[]" class="select2 m-b-10 select2-multiple"
                                                multiple="multiple" data-placeholder="Choose Product">
                                                <?php $__currentLoopData = $workplace->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($val->id); ?>"><?php echo e($val->title); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col-xs-4 ">
                                            <label for="role" class="m-t-20">User Permission</label>
                                            <select id="role" name="role" class="m-b-10 form-control">
                                                <option value="3">Sales Agent</option>
                                                <option value="2">Leader</option>
                                                <option value="1">Admin</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12 text-right m-t-20">
                                            <button type="submit" class="btn btn-danger"> <i
                                                    class="fa fa-check"></i>
                                                Save</button>
                                        </div>
                                    </div>
                                </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /#page-wrapper -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/malexs5/public_html/closor/resources/views/workplaces/invite.blade.php ENDPATH**/ ?>