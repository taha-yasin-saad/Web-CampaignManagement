<?php echo e($slot); ?>

<?php /**PATH /home/malexs5/public_html/closor/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>