<?php $__env->startSection('content'); ?>

<!-- ============================================================== -->
<!-- Page Content -->
<!-- ============================================================== -->
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row bg-title">
            <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                <h4 class="page-title">Team</h4>
            </div>
            <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                <ol class="breadcrumb">
                    <li><a href="#"><?php echo e($workplace->title); ?></a></li>
                    <li class="active">Team</li>
                </ol>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <div class="panel m-b-20">
                    <div class="row panel-heading">
                        <div class="col-md-6 col-sm-6 col-xs-6">
                            <p><?php echo e(count($workplace->users)); ?></p>
                            <span class="text-muted m-r-10">Users</span>
                        </div>
                        <div class="col-md-6 col-sm-6 col-xs-6 text-right">
                            <?php if(get_role($workplace->id) == 0 || get_role($workplace->id) == 1): ?>
                            <a>
                                <a class=" btn btn-danger m-t-20" href="<?php echo e(url('invite').'/'.$workplace->id); ?>"
                                    type="button">Invite New User</a>
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="panel">
                    <?php if(session('success')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('success')); ?>

                    </div>
                    <?php endif; ?>
                    <div class="panel-heading">MANAGE USERS</div>
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered manage-u-table">
                            <thead>
                                <tr>
                                    <th style="width: 70px;" class="text-center">#</th>
                                    <th>USER</th>
                                    <th>PRODUCTS</th>
                                    <th>USER ROLE</th>
                                    <th>TOTAL LEADS</th>
                                    <th>CONTACTED LEADS</th>
                                    <th>QUALIFIED LEADS</th>
                                    <th>CONVERSION RATE</th>
                                    <?php if(get_role($workplace->id) == 0 || get_role($workplace->id) == 1): ?>
                                    <th colspan="3">MANAGE</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $workplace->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(!isset($product_id)||in_array($product_id,$value->selected_ids)): ?>
                                <tr>
                                    <td class="text-center"><?php echo e($key+1); ?></td>
                                    <td>
                                        <span class="font-medium">
                                            <?php if($value->name): ?>
                                            <?php echo e($value->name); ?>

                                            <?php else: ?>
                                            <?php echo e($value->email); ?>

                                            <?php endif; ?>
                                        </span><span class="badge-success badge">Online</span>
                                        <br><span class="text-muted">Joined at 15/2/2020</span>
                                    </td>
                                    <td>
                                        <?php $__currentLoopData = $value->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($val->workplace_id == $workplace->id): ?>
                                        <span class="bg-inverse badge"><?php echo e($val->title); ?></span><br>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td>
                                        <?php if($value->pivot->role == 0): ?>
                                        Owner
                                        <?php elseif($value->pivot->role == 1): ?>
                                        Admin
                                        <?php elseif($value->pivot->role == 2): ?>
                                        Leader
                                        <?php elseif($value->pivot->role == 3): ?>
                                        Sales Agent
                                        <?php endif; ?>
                                    </td>
                                    <td>514</td>
                                    <td>214</td>
                                    <td>78</td>
                                    <td>20%</td>
                                    <?php if(get_role($workplace->id) == 0 || get_role($workplace->id) == 1): ?>
                                    <td>
                                    <?php if($value->pivot->role != 0): ?>
                                        <input onchange="change_status(this)" type="checkbox" <?php if($value->pivot->status
                                        == 1): ?>
                                        checked
                                        <?php endif; ?>
                                        class="js-switch" data-color="#2cabe3" name="status" />
                                        <input type="hidden" id="current_user<?php echo e($value->id); ?>" value="<?php echo e($value->id); ?>" />
                                    <?php endif; ?>
                                    </td>
                                    <?php $__env->startSection('status'); ?>
                                    <script>
                                    var baseUrl = "<?php echo e(url('/')); ?>";

                                    function change_status(activate) {
                                        console.log(activate.checked)
                                        var id = document.getElementById("current_user" +<?php echo e($value->id); ?>).value;
                                        console.log(id)
                                        var status;

                                        if (activate.checked == true) {
                                            status = 1;
                                        } else {
                                            status = 0;
                                        }

                                        $.ajaxSetup({
                                            headers: {
                                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                                            }
                                        });
                                        $.ajax({
                                            type: 'GET',
                                            url: baseUrl + '/active_user_in_workspace/' + status + '/' + id +
                                                '/' + <?php echo e($workplace->id); ?>,
                                            success: function(data) {

                                                console.log(data)

                                            }
                                        });
                                    }
                                    </script>
                                    <?php $__env->stopSection(); ?>
                                    <td> 
                                        <?php if($value->pivot->role != 0): ?>
                                        <button type="button"
                                            class="btn btn-info btn-outline btn-circle btn-lg m-r-5 remove_user_from_workspace_alert"
                                            id="sa-warning" onclick=" delete_user();">
                                            <i class="icon-trash"></i>
                                        </button>
                                        <?php endif; ?>
                                        <script>
                                        function delete_user() {
                                            swal({
                                                title: "Are you sure?",
                                                text: "The user will be removed from entire workspace !",
                                                type: "warning",
                                                showCancelButton: true,
                                                confirmButtonColor: "#DD6B55",
                                                confirmButtonText: "Yes, delete it!",
                                                closeOnConfirm: true
                                            }, function() {
                                                document.getElementById('remove_user_from_workspace' + <?php echo e($value->id); ?>).submit();
                                            });
                                        }
                                        </script>
                                        <form method="GET" id="remove_user_from_workspace<?php echo e($value->id); ?>"
                                            action="<?php echo e(url('remove_user_from_workspace').'/'.$value->id.'/'.$workplace->id); ?>"
                                            style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                        
                                        <a class="dropdown">
                                            <a class="btn btn-info btn-outline btn-circle btn-lg m-r-5"
                                                id="addRemoveLeadDropDown" data-toggle="dropdown" href="#"
                                                aria-expanded="false" role="button"><i class="ti-settings"></i></a>
                                            <div class="dropdown-menu bullet dropdown-menu-right"
                                                aria-labelledby="addRemoveLeadDropDown" role="menu"
                                                style="top: unset!important;">
                                                <div class="white-box">
                                                    <h3 class="box-title m-b-0">Add Or Remove Product</h3>
                                                    <p class="text-muted m-b-30"> Only these sales agents will receive
                                                        leads related to this product</p>
                                                    <form action="<?php echo e(url('add_product_to_user')); ?>" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="user_id" value="<?php echo e($value->id); ?>">
                                                        <input type="hidden" name="workplace_id"
                                                            value="<?php echo e($workplace->id); ?>">
                                                        <select name="products[]"
                                                            class="select2 m-b-10 select2-multiple" multiple="multiple"
                                                            data-placeholder="Choose">
                                                            <?php $__currentLoopData = $workplace->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($val->id); ?>" <?php if(in_array($val->id,
                                                                $value->selected_ids)): ?> selected <?php endif; ?>
                                                                ><?php echo e($val->title); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                        <div class="form-actions text-right">
                                                            <button type="submit" class="btn btn-success"> <i
                                                                    class="fa fa-check"></i> Save</button>
                                                            <button type="button" class="btn btn-dark">Cancel</button>
                                                        </div>
                                                    </form>

                                                </div>
                                            </div>
                                        </a>
                                    </td>
                                    <td>
                                        <?php if($value->pivot->role != 0): ?>
                                        <a class="dropdown">
                                            <a class="btn btn-info btn-outline btn-circle btn-lg m-r-5"
                                                id="editRoleDropDown" data-toggle="dropdown" href="#"
                                                aria-expanded="false" role="button"><i class="ti-pencil-alt"></i></a>
                                            <div class="dropdown-menu bullet dropdown-menu-right"
                                                aria-labelledby="editRoleDropDown" role="menu"
                                                style="top: unset!important;">
                                                <div class="white-box">
                                                    <h3 class="box-title m-b-0">Edit Role</h3>
                                                    <p class="text-muted m-b-30"> Only these Owner and Admin will Edit
                                                        roles</p>
                                                    <form action="<?php echo e(url('edit_user_role')); ?>" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="user_id" value="<?php echo e($value->id); ?>">
                                                        <input type="hidden" name="workplace_id"
                                                            value="<?php echo e($workplace->id); ?>">
                                                        <select id="role" name="role" class="select2 form-control ">
                                                            <option value="3">Sales Agent</option>
                                                            <option value="2">Leader</option>
                                                            <option value="1">Admin</option>
                                                        </select>
                                                        <div class="form-actions text-right">
                                                            <button type="submit" class="btn btn-success"> <i
                                                                    class="fa fa-check"></i> Save</button>
                                                            <button type="button" class="btn btn-dark">Cancel</button>
                                                        </div>
                                                    </form>

                                                </div>
                                            </div>
                                        </a>
                                        <?php endif; ?>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/malexs5/public_html/closor/resources/views/workplaces/team.blade.php ENDPATH**/ ?>