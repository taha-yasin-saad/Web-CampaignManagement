<?php $__env->startSection('content'); ?>

<!-- ============================================================== -->
<!-- Page Content -->
<!-- ============================================================== -->
<div id="page-wrapper">
  <div class="container-fluid">
    <div class="row bg-title">
      <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
        <h4 class="page-title">Lead Page</h4>
      </div>
      <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
        <a href="javascript: void(0);" target="_blank" class="btn btn-danger pull-right m-l-20 hidden-xs hidden-sm waves-effect waves-light">Admin Panel</a>
        <ol class="breadcrumb">
          <li><a href="#">Dashboard</a></li>
          <li class="active">Lead Page</li>
        </ol>
      </div>
    </div>
    <!-- .row -->
    <div class="row">
      <div class="col-md-8 col-md-offset-2 col-xs-12 white-box">
        <div>
          
          <div class="tab-content">
              <div class="form-group">
                <label class="col-md-6">Full Name</label>
                <div class="col-md-6">
                  <p><?php echo e($lead->name); ?></p>
                </div>
              </div>
              <div class="form-group">
                <label class="col-md-6">Email</label>
                <div class="col-md-6">
									<p><?php echo e($lead->email); ?></p>
								</div>
              </div>
              <div class="form-group">
								<label class="col-md-6">Phone No</label>
                <div class="col-md-6">
									<p><?php echo e($lead->phone); ?></p>
                  
                </div>
              </div>
              <div class="form-group">
                <label class="col-md-6">Product</label>
                <div class="col-md-6">
									<p><?php echo e($lead->product->title); ?></p>
                  
                </div>
							</div>
							<div class="form-group">
								<label class="col-md-6">Submitted On</label>
                <div class="col-md-6">
									<p><?php echo e($lead->created_at); ?></p>
                </div>
							</div>
							
          </div>
        </div>
      </div>
		</div>
		<div class="row">
      <div class="col-md-8 col-md-offset-2 col-xs-12 white-box">
        <div>
          
				<div class="tab-content">
					<div class="form-group">
						<?php $__currentLoopData = $ldata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<label class="col-md-6"><?php echo e($key); ?></label>
						<div class="col-md-6">
							<p><?php echo e($value); ?></p>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
			</div>
		</div>
		
    <!-- /.row -->
  </div>
  <!-- /#page-wrapper -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/malexs5/public_html/closor/resources/views/leads/onelead.blade.php ENDPATH**/ ?>